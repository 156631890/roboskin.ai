"""Binary hidden-state information-value microbenchmark; Python 3, no required deps.

The model is an analytically specified decision problem, NOT a robotics experiment.
Optional plots require an already installed matplotlib. Run: python run_benchmark.py
"""
from __future__ import annotations

import argparse
import csv
import hashlib
import itertools
import json
import math
import random
import statistics
from pathlib import Path

CORE = ("passive", "always_probe", "selective", "uninformative_probe", "dummy_probe", "oracle")
STRESS = ("flipped_uncalibrated", "flipped_calibrated")
ALL = CORE + STRESS
COMPARISONS = (("selective", "passive"), ("selective", "always_probe"),
               ("always_probe", "dummy_probe"), ("uninformative_probe", "dummy_probe"),
               ("flipped_uncalibrated", "selective"), ("flipped_calibrated", "selective"))
T975_DF19 = 2.093024054408263


def after_probe_value(b: float, p: float) -> float:
    """Expected posterior-MAP correctness, before observing the probe outcome."""
    return max(b * p, (1 - b) * (1 - p)) + max(b * (1 - p), (1 - b) * p)


def should_probe(b: float, p: float, cost: float) -> bool:
    # Skip exact indifference; tolerance prevents floating-point boundary probing.
    return after_probe_value(b, p) - max(b, 1 - b) > cost + 1e-12


def map_action(b: float, token: int, p: float, fallback: int) -> int:
    state1 = b * (p if token else 1 - p)
    state0 = (1 - b) * (1 - p if token else p)
    if math.isclose(state1, state0, rel_tol=0.0, abs_tol=1e-12):
        return fallback
    return int(state1 > state0)


def decision(policy: str, s: int, v: int, x: int, z: int,
             q: float, p: float, cost: float) -> tuple[int, int]:
    b = q if v else 1 - q
    if policy == "oracle":
        return s, 0  # Privileged latent-state upper bound, never implementable here.
    if policy == "passive":
        return v, 0
    if policy == "dummy_probe":
        return v, 1  # Same charge/budget as one probe, no added observation.
    if policy == "uninformative_probe":
        return map_action(b, z, 0.5, v), 1  # Correctly models the independent coin.
    probe = 1 if policy == "always_probe" else int(should_probe(b, p, cost))
    if not probe:
        return v, 0
    token = 1 - x if policy in STRESS else x
    if policy == "flipped_calibrated":
        token = 1 - token  # Known, supplied encoding calibration; never learned.
    return map_action(b, token, p, v), 1


def exact_metrics(policy: str, q: float, p: float, cost: float) -> dict[str, float]:
    success = probe_rate = 0.0
    for s, v, x, z in itertools.product((0, 1), repeat=4):
        prob = 0.5 * (q if v == s else 1 - q) * (p if x == s else 1 - p) * 0.5
        action, probe = decision(policy, s, v, x, z, q, p, cost)
        success += prob * (action == s)
        probe_rate += prob * probe
    return {"success": success, "probe_rate": probe_rate,
            "utility": success - cost * probe_rate}


def write_csv(path: Path, rows: list[dict]) -> None:
    with path.open("w", newline="", encoding="utf-8") as f:
        writer = csv.DictWriter(f, fieldnames=list(rows[0]))
        writer.writeheader()
        writer.writerows(rows)


def validate_formula() -> dict:
    max_error = 0.0
    for i in range(101):
        b = i / 100
        for j in range(51):
            p = 0.5 + j / 100
            max_error = max(max_error, abs(after_probe_value(b, p) - max(b, 1 - b, p)))
    assert max_error < 1e-12
    assert not should_probe(0.8, 0.9, 0.1), "Must skip at indifference."
    for q in (0.5, 0.75, 0.95):
        for p in (0.5, 0.7, 0.9, 1.0):
            for cost in (0.0, 0.1, 0.5):
                actual = exact_metrics("selective", q, p, cost)["utility"]
                expected = max(q, max(q, p) - cost)
                assert abs(actual - expected) < 1e-12
                assert abs(exact_metrics("flipped_calibrated", q, p, cost)["utility"] - actual) < 1e-12
    return {"formula_grid_points": 5151, "maximum_absolute_error": max_error,
            "boundary_and_enumeration_assertions": "passed"}


def main() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--episodes", type=int, default=10000, help="Episodes per seed and q.")
    parser.add_argument("--output", type=Path, default=Path(__file__).resolve().parent / "results")
    args = parser.parse_args()
    if args.episodes < 2:
        parser.error("--episodes must be at least 2")
    out = args.output.resolve()
    out.mkdir(parents=True, exist_ok=True)
    checks = validate_formula()
    qs, p, cost = (0.5, 0.75, 0.95), 0.9, 0.1
    seeds = list(range(2026092700, 2026092720))
    seed_rows, aggregate_rows, pair_seed_rows, pair_rows = [], [], [], []
    for q in qs:
        for seed in seeds:
            rng = random.Random(seed)
            successes = dict.fromkeys(ALL, 0)
            probes = dict.fromkeys(ALL, 0)
            for _ in range(args.episodes):
                s = int(rng.random() < 0.5)
                uv, ux, uz = rng.random(), rng.random(), rng.random()
                v, x, z = (s if uv < q else 1 - s), (s if ux < p else 1 - s), int(uz < 0.5)
                for policy in ALL:
                    action, probe = decision(policy, s, v, x, z, q, p, cost)
                    successes[policy] += int(action == s)
                    probes[policy] += probe
            means = {}
            for policy in ALL:
                success = successes[policy] / args.episodes
                probe_rate = probes[policy] / args.episodes
                means[policy] = success - cost * probe_rate
                seed_rows.append({"q": q, "p": p, "cost": cost, "seed": seed,
                                  "episodes": args.episodes, "policy": policy,
                                  "success": success, "probe_rate": probe_rate,
                                  "utility": means[policy]})
            for a, b in COMPARISONS:
                pair_seed_rows.append({"q": q, "seed": seed, "policy_a": a, "policy_b": b,
                                       "paired_utility_difference": means[a] - means[b]})
        for policy in ALL:
            rows = [r for r in seed_rows if r["q"] == q and r["policy"] == policy]
            exact = exact_metrics(policy, q, p, cost)
            row = {"q": q, "p": p, "cost": cost, "policy": policy,
                   "seed_count": len(seeds), "episodes_total": args.episodes * len(seeds)}
            for key in ("success", "utility", "probe_rate"):
                vals = [r[key] for r in rows]
                mean = statistics.mean(vals)
                half = T975_DF19 * statistics.stdev(vals) / math.sqrt(len(seeds))
                row.update({f"exact_{key}": exact[key], f"mc_{key}": mean,
                            f"mc_{key}_ci95_low": mean - half, f"mc_{key}_ci95_high": mean + half})
            aggregate_rows.append(row)
        for a, b in COMPARISONS:
            vals = [r["paired_utility_difference"] for r in pair_seed_rows
                    if r["q"] == q and r["policy_a"] == a and r["policy_b"] == b]
            mean = statistics.mean(vals)
            half = T975_DF19 * statistics.stdev(vals) / math.sqrt(len(seeds))
            pair_rows.append({"q": q, "policy_a": a, "policy_b": b,
                              "exact_utility_difference": exact_metrics(a, q, p, cost)["utility"] - exact_metrics(b, q, p, cost)["utility"],
                              "mc_paired_utility_difference": mean,
                              "ci95_low": mean - half, "ci95_high": mean + half,
                              "ci_method": "paired_seed_means_student_t_df19_MC_error_only"})

    scan = []
    for q in qs:
        for ip in range(51):
            pp = 0.5 + ip / 100
            for ic in range(51):
                cc = ic / 100
                baseline = max(q, 1 - q)
                probe = int(should_probe(q, pp, cc))
                scan.append({"q": q, "p": pp, "cost": cc,
                             "passive_success": baseline, "always_success": max(q, pp),
                             "passive_utility": baseline, "always_utility": max(q, pp) - cc,
                             "selective_success": max(q, pp) if probe else baseline,
                             "selective_utility": max(baseline, max(q, pp) - cc),
                             "selective_probe_rate": probe,
                             "selective_gain_over_passive": max(0.0, max(q, pp) - baseline - cc)})
    write_csv(out / "per_seed_metrics.csv", seed_rows)
    write_csv(out / "aggregate_metrics.csv", aggregate_rows)
    write_csv(out / "paired_per_seed.csv", pair_seed_rows)
    write_csv(out / "paired_comparisons.csv", pair_rows)
    write_csv(out / "exact_parameter_scan.csv", scan)
    meta = {
        "model": "Binary hidden-state sensor-decision problem, not a robotics experiment",
        "prior": 0.5, "q_values": qs, "p": p, "cost": cost,
        "seeds": seeds, "episodes_per_seed_per_q": args.episodes,
        "total_unique_episode_scenarios": args.episodes * len(seeds) * len(qs),
        "rng": "Python random.Random (Mersenne Twister)",
        "common_random_numbers": "Within each episode all policies share s,v,x,z; reset same seed across q also couples scenarios.",
        "ci": "Two-sided Student-t intervals over 20 paired seed means; df=19; estimates Monte Carlo sampling uncertainty only.",
        "oracle": "Latent s supplied without probe cost; unattainable upper bound.",
        "dummy_probe": "Same abstract one-probe cost and budget; elapsed wall time is not simulated.",
        "flipped_sensor": "Raw token x is replaced by 1-x. Uncalibrated policy wrongly retains p=.9 channel; calibrated policy uses a supplied deterministic inverse encoding. No calibration is learned.",
        "checks": checks,
        "script_sha256": hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),
        "aggregates": aggregate_rows, "paired_comparisons": pair_rows,
        "exact_parameter_scan_rows": len(scan)
    }
    plots = make_plots(out, aggregate_rows, scan)
    meta["plots"] = plots
    (out / "results.json").write_text(json.dumps(meta, indent=2) + "\n", encoding="utf-8")
    (out.parent / "summary.md").write_text(make_summary(meta), encoding="utf-8")
    print(json.dumps({"output": str(out), "checks": checks, "plots": plots,
                      "aggregate_rows": len(aggregate_rows), "scan_rows": len(scan)}, indent=2))


def make_plots(out: Path, rows: list[dict], scan: list[dict]) -> list[str]:
    try:
        import matplotlib
        matplotlib.use("Agg")
        import matplotlib.pyplot as plt
    except ImportError:
        return []
    plt.rcParams.update({"font.family": "DejaVu Sans", "font.size": 10,
                         "axes.spines.top": False, "axes.spines.right": False,
                         "pdf.fonttype": 42, "ps.fonttype": 42})
    colors = {"passive": "#667085", "always_probe": "#D65A31", "selective": "#087E8B"}
    labels = {"passive": "Passive MAP", "always_probe": "Always probe", "selective": "Exact VOI selection"}
    fig, axes = plt.subplots(1, 2, figsize=(10, 3.9), layout="constrained")
    gridq = [0.5 + i / 1000 for i in range(491)]
    for ax, metric in zip(axes, ("success", "utility")):
        for k, policy in enumerate(colors):
            vals = [exact_metrics(policy, q, 0.9, 0.1)[metric] for q in gridq]
            ax.plot(gridq, vals, color=colors[policy], label=labels[policy], linewidth=1.9,
                    linestyle=("--" if policy == "always_probe" else "-"))
            data = [r for r in rows if r["policy"] == policy]
            ax.errorbar([r["q"] + (k - 1) * .002 for r in data],
                        [r[f"mc_{metric}"] for r in data],
                        yerr=[r[f"mc_{metric}_ci95_high"] - r[f"mc_{metric}"] for r in data],
                        fmt="o", ms=4, color=colors[policy], capsize=3, zorder=5)
        ax.set_xlabel("Visual signal accuracy q")
        ax.set_ylabel("Success probability" if metric == "success" else "Mean net utility (success - probe cost)")
        ax.set_xlim(.48, 1.0)
        ax.set_ylim(.37 if metric == "utility" else .47, 1.015)
        ax.grid(alpha=.15)
        ax.axvline(.8, color="#AAAAAA", linewidth=.8, linestyle=":")
    axes[0].legend(loc="lower right", frameon=False)
    fig.suptitle("Specified binary microbenchmark: p = 0.90, c = 0.10", fontsize=12)
    for ext in ("png", "pdf"):
        fig.savefig(out / f"main_comparison.{ext}", dpi=220, bbox_inches="tight")
    plt.close(fig)
    panel = [r for r in scan if r["q"] == .75]
    # Rows in image correspond to c, columns to p.
    matrix = [[next(r["selective_gain_over_passive"] for r in panel
                    if abs(r["p"] - (.5 + ip / 100)) < 1e-9 and abs(r["cost"] - ic / 100) < 1e-9)
               for ip in range(51)] for ic in range(51)]
    fig, ax = plt.subplots(figsize=(6.3, 4.3), layout="constrained")
    im = ax.imshow(matrix, origin="lower", extent=(.495, 1.005, -.005, .505),
                   aspect="auto", interpolation="nearest", cmap="viridis", vmin=0, vmax=.25)
    ax.plot([.75, 1.0], [0, .25], color="white", linestyle="--", linewidth=1.5,
            label="Indifference: p - q = c")
    ax.set(xlabel="Probe accuracy p", ylabel="Probe cost c", xlim=(.5, 1), ylim=(0, .5),
           title="Exact incremental utility of selective probing (q = 0.75)")
    ax.legend(loc="upper left", facecolor="#263B51", edgecolor="none", labelcolor="white", fontsize=8)
    fig.colorbar(im, ax=ax, label="Selective utility minus passive utility")
    for ext in ("png", "pdf"):
        fig.savefig(out / f"parameter_scan.{ext}", dpi=220, bbox_inches="tight")
    plt.close(fig)
    return ["main_comparison.png", "main_comparison.pdf", "parameter_scan.png", "parameter_scan.pdf"]


def make_summary(meta: dict) -> str:
    rows = meta["aggregates"]
    lines = ["# Binary interaction-value microbenchmark: executed results", "",
             "This is a synthetic, fully specified decision problem. No robot, learned representation, learned policy, real sensor, or physical experiment is involved.", "",
             "## Protocol", "",
             "Latent state s ~ Bernoulli(0.5). Visual observation v has accuracy q in {0.50, 0.75, 0.95}; probe x has accuracy p=0.90. Observations are conditionally independent given s. Terminal action a yields reward 1 iff a=s. One probe costs c=0.10. The probe reveals a signal but does not change s. Utility is success minus c times the probe indicator.", "",
             f"Executed {len(meta['seeds'])} seeds ({meta['seeds'][0]} to {meta['seeds'][-1]}), {meta['episodes_per_seed_per_q']:,} episodes per seed and q; {meta['total_unique_episode_scenarios']:,} episode-scenarios in total. All policies share identical episode random variables. The same seeds also couple different q conditions.", "",
             "For belief b=P(s=1|v), exact expected post-probe MAP correctness is max(b,1-b,p) for p>=0.5. Probe iff max(b,1-b,p)-max(b,1-b)>c; skip at equality. Within any one fixed-q condition this binary symmetric model has constant confidence q, so selection is all-or-none, not episode-dependent. The benchmark demonstrates the value-of-information threshold only.", "",
             "## Core results", "",
             "| q | Policy | Exact success | MC success | Exact utility | MC utility | Probe rate |",
             "|---:|---|---:|---:|---:|---:|---:|"]
    for r in rows:
        if r["policy"] in CORE:
            lines.append(f"| {r['q']:.2f} | {r['policy']} | {r['exact_success']:.6f} | {r['mc_success']:.6f} | {r['exact_utility']:.6f} | {r['mc_utility']:.6f} | {r['mc_probe_rate']:.2f} |")
    lines.extend(["", "The oracle is given the true latent state for free and is an unattainable upper bound. The dummy baseline pays the same abstract one-probe cost and budget but obtains no signal; this model does not simulate wall-clock latency. The uninformative baseline receives a fair coin and correctly models its accuracy as 0.5.", "",
                  "## Paired utility comparisons", "",
                  "95% intervals use Student-t (df=19) across 20 seed-wise paired means. They quantify Monte Carlo sampling error under this fixed, correctly specified model; they do not measure real-world uncertainty, generalization, calibration risk, or robustness. A zero-width interval arises for policies identical episode-by-episode or differing by a deterministic charge.", "",
                  "| q | A minus B | Exact difference | MC difference | 95% MC interval |",
                  "|---:|---|---:|---:|---:|"])
    for r in meta["paired_comparisons"]:
        lines.append(f"| {r['q']:.2f} | {r['policy_a']} - {r['policy_b']} | {r['exact_utility_difference']:.6f} | {r['mc_paired_utility_difference']:.6f} | [{r['ci95_low']:.6f}, {r['ci95_high']:.6f}] |")
    lines.extend(["", "## Encoding stress test", "",
                  "The raw probe token is flipped. An uncalibrated policy still assumes positive accuracy p=0.9, whereas the calibrated policy receives the known inverse token mapping. No adapter or calibration is learned. This is an encoding/misspecification stress test, not evidence of cross-embodiment transfer.", "",
                  "| q | Policy | Exact success | MC success | Exact utility | MC utility |",
                  "|---:|---|---:|---:|---:|---:|"])
    for r in rows:
        if r["policy"] in STRESS:
            lines.append(f"| {r['q']:.2f} | {r['policy']} | {r['exact_success']:.6f} | {r['mc_success']:.6f} | {r['exact_utility']:.6f} | {r['mc_utility']:.6f} |")
    lines.extend(["", "At q=0.50 and 0.75, blindly reusing the nominal sensor interpretation reduces exact success to 0.10 and net utility to 0.00. Supplied calibration recovers nominal results. At q=0.95 selection skips the probe, so its encoding is irrelevant.", "",
                  "## Exact parameter sweep and checks", "",
                  f"The scan contains {meta['exact_parameter_scan_rows']:,} rows: q in {{0.50,0.75,0.95}}, p=0.50..1.00 and c=0.00..0.50 at increments of 0.01. It uses analytical values, not additional simulated trials. Selective gain over passive equals max(0,p-q-c). At the equality boundary the policy skips probing.", "",
                  f"The closed-form posterior-MAP value was checked against explicit two-outcome enumeration on 5,151 (b,p) pairs; largest absolute error: {meta['checks']['maximum_absolute_error']:.3g}. Boundary and joint-state enumeration assertions passed. Formula validation is a consistency check, not independent empirical support for the assumed model.", "",
                  "## Limits", "",
                  "This exercise supports only the decision-theoretic claim that a correctly modeled information-bearing observation can justify its cost. It cannot establish emergence, scaling laws, a learned world model, superiority over VLA/robot baselines, physical contact safety, causal identification from observational logs, or cross-robot generalization. The state is binary and static; the sensor channels, cost, and decision rule are supplied; the observation does not alter physical dynamics. Within a fixed q, selective probing has no per-episode confidence variation.", "",
                  "## Artifacts", "",
                  "- `run_benchmark.py`: standalone executable and analytical consistency checks.",
                  "- `results/results.json`: parameters, seeds, checks, source hash, aggregate and paired results.",
                  "- `results/per_seed_metrics.csv`, `aggregate_metrics.csv`: all policy metrics.",
                  "- `results/paired_per_seed.csv`, `paired_comparisons.csv`: paired utility differences.",
                  "- `results/exact_parameter_scan.csv`: exact p/c scan for each q.",
                  "- `results/main_comparison.{png,pdf}`, `parameter_scan.{png,pdf}`: figures if matplotlib is available.", ""])
    return "\n".join(lines)


if __name__ == "__main__":
    main()
